package com.parkingapp

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var btnParkHere: Button

    private var carMarker: Marker? = null
    private var currentLocationMarker: Marker? = null

    // Location permission request
    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        when {
            permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false) -> {
                // Precise location access granted.
                initializeMap()
            }
            permissions.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false) -> {
                // Only approximate location access granted.
                initializeMap()
            }
            else -> {
                // No location access granted.
                Toast.makeText(this, "Location permission is required to show your current location", Toast.LENGTH_LONG).show()
                initializeMapWithoutLocation()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        // Initialize FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Initialize UI components
        btnParkHere = findViewById(R.id.buttonParkHere)
        btnParkHere.setOnClickListener {
            updateCarLocation()
        }

        // Check for location permission
        checkLocationPermission()
    }

    private fun checkLocationPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED -> {
                // Permission already granted
                initializeMap()
            }
            shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION) -> {
                // Show an explanation to the user
                showPermissionRationaleDialog()
            }
            else -> {
                // Request the permission
                locationPermissionRequest.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        }
    }

    private fun showPermissionRationaleDialog() {
        AlertDialog.Builder(this)
            .setTitle("Location Permission Needed")
            .setMessage("This app needs the Location permission to show your current location and help you find your parked car.")
            .setPositiveButton("OK") { _, _ ->
                locationPermissionRequest.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                initializeMapWithoutLocation()
            }
            .create()
            .show()
    }

    private fun initializeMap() {
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun initializeMapWithoutLocation() {
        // Initialize map without location services
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Try to enable current location layer if permission is granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
            getCurrentLocation()
        }

        // Load saved car location
        loadSavedCarLocation()

        // Set map click listener for manual placement (optional)
        mMap.setOnMapClickListener { latLng ->
            // Optional: allow user to tap on map to set car location
            showSetLocationDialog(latLng)
        }
    }

    private fun getCurrentLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                location?.let {
                    val currentLatLng = LatLng(it.latitude, it.longitude)

                    // Add or update current location marker
                    currentLocationMarker?.remove()
                    currentLocationMarker = mMap.addMarker(
                        MarkerOptions()
                            .position(currentLatLng)
                            .title("Your Current Location")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                    )

                    // Move camera to current location if no car location is saved
                    if (carMarker == null) {
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f))
                    }
                }
            }
    }

    private fun updateCarLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Location permission required", Toast.LENGTH_SHORT).show()
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                location?.let {
                    val carLatLng = LatLng(it.latitude, it.longitude)
                    setCarMarker(carLatLng)
                    saveLocation(carLatLng)
                    Toast.makeText(this, "Car location updated!", Toast.LENGTH_SHORT).show()
                } ?: run {
                    Toast.makeText(this, "Unable to get current location", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun setCarMarker(latLng: LatLng) {
        carMarker?.remove()
        carMarker = mMap.addMarker(
            MarkerOptions()
                .position(latLng)
                .title("Your Parked Car")
                .snippet("Last updated parking location")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_car))
        )

        // Move camera to car location
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17f))
    }

    // BONUS: Save location to SharedPreferences
    private fun saveLocation(latLng: LatLng) {
        getPreferences(MODE_PRIVATE)?.edit()?.apply {
            putString("latitude", latLng.latitude.toString())
            putString("longitude", latLng.longitude.toString())
            apply()
        }
    }

    // BONUS: Load saved location from SharedPreferences
    private fun loadSavedCarLocation() {
        val sharedPreferences = getPreferences(MODE_PRIVATE)
        val latitude = sharedPreferences.getString("latitude", null)?.toDoubleOrNull() ?: return
        val longitude = sharedPreferences.getString("longitude", null)?.toDoubleOrNull() ?: return

        val savedLatLng = LatLng(latitude, longitude)
        setCarMarker(savedLatLng)
    }

    private fun showSetLocationDialog(latLng: LatLng) {
        AlertDialog.Builder(this)
            .setTitle("Set Car Location")
            .setMessage("Do you want to set your car location here?")
            .setPositiveButton("Yes") { _, _ ->
                setCarMarker(latLng)
                saveLocation(latLng)
                Toast.makeText(this, "Car location set!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("No", null)
            .show()
    }
}